// Programa principal: crea los datos de prueba y muestra los menús por consola.
import java.util.List;
import java.util.Scanner;

public class Main {
    static final Scanner in = new Scanner(System.in);

    public static void main(String[] args) {
        // ---- Datos de prueba ----
        Cliente ana = new Cliente("C1", "Ana", "Gómez", "1001");
        CuentaAhorros ahorros = new CuentaAhorros("AH-001", 500_000, 0.01);
        CuentaCorriente corriente = new CuentaCorriente("CO-001", 200_000, 100_000);
        ana.agregarCuenta(ahorros);
        ana.agregarCuenta(corriente);
        Tarjeta tarjeta = new Tarjeta("4000123412341234", "1234", ana);
        ana.agregarTarjeta(tarjeta);

        CajeroAutomatico cajero = new CajeroAutomatico("ATM-01", 5_000_000);

        System.out.println("=== CAJERO AUTOMÁTICO ===");
        System.out.println("(Tarjeta de prueba: 4000123412341234 | PIN: 1234)");

        while (true) {
            System.out.print("\nIngrese número de tarjeta (o 'salir'): ");
            String num = in.nextLine().trim();
            if (num.equalsIgnoreCase("salir")) break;
            if (!num.equals(tarjeta.getNumero())) { System.out.println("Tarjeta no reconocida."); continue; }
            if (tarjeta.isBloqueada()) { System.out.println("Tarjeta bloqueada. Contacte al banco."); continue; }

            boolean entro = false;
            while (!tarjeta.isBloqueada()) {
                System.out.print("PIN: ");
                if (cajero.autenticar(tarjeta, in.nextLine().trim())) { entro = true; break; }
                if (tarjeta.isBloqueada()) System.out.println("PIN incorrecto. Tarjeta BLOQUEADA.");
                else System.out.println("PIN incorrecto. Intentos restantes: " + tarjeta.getIntentosRestantes());
            }
            if (entro) menu(cajero, ana);
        }
        System.out.println("Gracias por usar el cajero.");
    }

    static void menu(CajeroAutomatico cajero, Cliente cli) {
        System.out.println("\nBienvenida/o, " + cli.getResumen());
        boolean activo = true;
        while (activo) {
            System.out.println("\n1. Consultar saldo  2. Retirar  3. Depositar  4. Transferir  5. Historial  6. Salir");
            System.out.print("Opción: ");
            String op = in.nextLine().trim();
            try {
                switch (op) {
                    case "1" -> {
                        Cuenta c = elegirCuenta(cli, "Cuenta");
                        System.out.printf("Saldo %s: $%,.0f%n", c.getTipo(), cajero.consultarSaldo(c));
                    }
                    case "2" -> {
                        Cuenta c = elegirCuenta(cli, "Retirar de");
                        double m = leerMonto();
                        System.out.println(cajero.retirar(c, m) ? "Retiro exitoso. Retire su dinero."
                                : "Retiro rechazado (fondos, límite $1.000.000, múltiplos de $10.000 o efectivo del cajero).");
                    }
                    case "3" -> {
                        Cuenta c = elegirCuenta(cli, "Depositar en");
                        System.out.println(cajero.depositar(c, leerMonto()) ? "Depósito exitoso." : "Monto inválido.");
                    }
                    case "4" -> {
                        Cuenta o = elegirCuenta(cli, "Cuenta origen");
                        Cuenta d = elegirCuenta(cli, "Cuenta destino");
                        System.out.println(cajero.transferir(o, d, leerMonto()) ? "Transferencia exitosa." : "Transferencia rechazada.");
                    }
                    case "5" -> {
                        List<Transaccion> h = cajero.getHistorial();
                        if (h.isEmpty()) System.out.println("Sin movimientos.");
                        h.forEach(t -> System.out.println(t.getComprobante()));
                    }
                    case "6" -> { cajero.cerrarSesion(); activo = false; System.out.println("Sesión cerrada."); }
                    default -> System.out.println("Opción inválida.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Ingrese un número válido.");
            }
        }
    }

    static Cuenta elegirCuenta(Cliente cli, String etiqueta) {
        List<Cuenta> cs = cli.getCuentas();
        while (true) {
            System.out.println(etiqueta + ":");
            for (int i = 0; i < cs.size(); i++)
                System.out.println("  " + (i + 1) + ". " + cs.get(i).getTipo() + " " + cs.get(i).getNumeroCuenta());
            System.out.print("Elija: ");
            try {
                int k = Integer.parseInt(in.nextLine().trim());
                if (k >= 1 && k <= cs.size()) return cs.get(k - 1);
            } catch (NumberFormatException ignored) { }
            System.out.println("Selección inválida.");
        }
    }

    static double leerMonto() {
        System.out.print("Monto: $");
        return Double.parseDouble(in.nextLine().trim());
    }
}
