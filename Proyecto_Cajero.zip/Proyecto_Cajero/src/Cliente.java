// Clase que representa al cliente del banco. Guarda sus datos personales, sus cuentas y sus tarjetas.
import java.util.ArrayList;
import java.util.List;

public class Cliente {
    private final String idCliente;
    private final String nombre;
    private final String apellido;
    private final String documento;
    private final List<Cuenta> cuentas = new ArrayList<>();
    private final List<Tarjeta> tarjetas = new ArrayList<>();

    public Cliente(String idCliente, String nombre, String apellido, String documento) {
        this.idCliente = idCliente;
        this.nombre = nombre;
        this.apellido = apellido;
        this.documento = documento;
    }

    public void agregarCuenta(Cuenta c) { cuentas.add(c); }
    public void agregarTarjeta(Tarjeta t) { tarjetas.add(t); }
    public List<Cuenta> getCuentas() { return cuentas; }
    public List<Tarjeta> getTarjetas() { return tarjetas; }
    public String getIdCliente() { return idCliente; }
    public String getNombre() { return nombre; }

    public String getResumen() {
        return nombre + " " + apellido + " (Doc: " + documento + ") - Cuentas: " + cuentas.size();
    }
}
