// Clase principal del cajero: revisa las reglas (límite, billetes, efectivo) y registra las transacciones.
import java.util.ArrayList;
import java.util.List;

public class CajeroAutomatico {
    public static final double LIMITE_RETIRO = 1_000_000;
    public static final double DENOMINACION = 10_000; // billete mínimo

    private final String idCajero;
    private double saldoEfectivo;
    private Tarjeta tarjetaActiva;
    private final List<Transaccion> historial = new ArrayList<>();

    public CajeroAutomatico(String idCajero, double saldoEfectivo) {
        this.idCajero = idCajero;
        this.saldoEfectivo = saldoEfectivo;
    }

    public boolean autenticar(Tarjeta t, String pin) {
        if (t.isBloqueada()) return false;
        if (t.validarPin(pin)) { tarjetaActiva = t; return true; }
        return false;
    }

    public void cerrarSesion() { tarjetaActiva = null; }
    public boolean haySesion() { return tarjetaActiva != null; }
    public Tarjeta getTarjetaActiva() { return tarjetaActiva; }

    private void exigirSesion() {
        if (tarjetaActiva == null) throw new IllegalStateException("No hay sesión activa");
    }

    public double consultarSaldo(Cuenta c) {
        exigirSesion();
        historial.add(new Transaccion("CONSULTA", c.getNumeroCuenta(), 0, true));
        return c.consultarSaldo();
    }

    public boolean retirar(Cuenta c, double monto) {
        exigirSesion();
        boolean ok = monto > 0
                && monto <= LIMITE_RETIRO
                && monto % DENOMINACION == 0
                && monto <= saldoEfectivo
                && c.retirar(monto);
        if (ok) saldoEfectivo -= monto;
        historial.add(new Transaccion("RETIRO", c.getNumeroCuenta(), monto, ok));
        return ok;
    }

    public boolean depositar(Cuenta c, double monto) {
        exigirSesion();
        boolean ok = monto > 0;
        if (ok) { c.depositar(monto); saldoEfectivo += monto; }
        historial.add(new Transaccion("DEPOSITO", c.getNumeroCuenta(), monto, ok));
        return ok;
    }

    public boolean transferir(Cuenta origen, Cuenta destino, double monto) {
        exigirSesion();
        boolean ok = monto > 0 && origen != destino && origen.retirar(monto);
        if (ok) destino.depositar(monto);
        historial.add(new Transaccion("TRANSFERENCIA", origen.getNumeroCuenta(), monto, ok));
        return ok;
    }

    public List<Transaccion> getHistorial() { return historial; }
    public double getSaldoEfectivo() { return saldoEfectivo; }
    public String getIdCajero() { return idCajero; }
}
