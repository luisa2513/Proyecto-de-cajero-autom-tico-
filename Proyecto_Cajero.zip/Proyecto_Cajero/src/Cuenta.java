// Clase abstracta: define lo que tienen en común todas las cuentas. Cada tipo de cuenta decide cómo se retira.
public abstract class Cuenta {
    protected final String numeroCuenta;
    protected double saldo;
    protected boolean activa = true;

    protected Cuenta(String numeroCuenta, double saldoInicial) {
        if (saldoInicial < 0) throw new IllegalArgumentException("Saldo inicial negativo");
        this.numeroCuenta = numeroCuenta;
        this.saldo = saldoInicial;
    }

    public void depositar(double monto) {
        if (monto <= 0) throw new IllegalArgumentException("El monto debe ser mayor a cero");
        saldo += monto;
    }

    /** Cada tipo de cuenta define cuánto puede retirar. */
    public abstract boolean retirar(double monto);

    public double consultarSaldo() { return saldo; }
    public String getNumeroCuenta() { return numeroCuenta; }
    public boolean isActiva() { return activa; }
    public abstract String getTipo();
}
