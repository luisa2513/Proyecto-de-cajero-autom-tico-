// Tarjeta débito. Guarda el PIN cifrado y bloquea la tarjeta si se falla 3 veces seguidas.
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;

public class Tarjeta {
    public static final int MAX_INTENTOS = 3;

    private final String numero;
    private final String pinHash;
    private final Cliente titular;
    private int intentosFallidos = 0;
    private boolean bloqueada = false;

    public Tarjeta(String numero, String pin, Cliente titular) {
        this.numero = numero;
        this.pinHash = hash(pin);
        this.titular = titular;
    }

    private static String hash(String texto) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] d = md.digest(texto.getBytes(StandardCharsets.UTF_8));
            StringBuilder sb = new StringBuilder();
            for (byte b : d) sb.append(String.format("%02x", b));
            return sb.toString();
        } catch (Exception e) {
            throw new IllegalStateException(e);
        }
    }

    /** Valida el PIN; al tercer error consecutivo la tarjeta se bloquea. */
    public boolean validarPin(String pin) {
        if (bloqueada) return false;
        if (pinHash.equals(hash(pin))) {
            intentosFallidos = 0;
            return true;
        }
        intentosFallidos++;
        if (intentosFallidos >= MAX_INTENTOS) bloquear();
        return false;
    }

    public void bloquear() { bloqueada = true; }
    public boolean isBloqueada() { return bloqueada; }
    public int getIntentosRestantes() { return MAX_INTENTOS - intentosFallidos; }
    public String getNumero() { return numero; }
    public Cliente getTitular() { return titular; }
}
