// Cuenta de ahorros: hereda de Cuenta. No permite retirar más que el saldo.
public class CuentaAhorros extends Cuenta {
    private final double tasaInteres; // tasa mensual, ej. 0.01 = 1%

    public CuentaAhorros(String numero, double saldoInicial, double tasaInteres) {
        super(numero, saldoInicial);
        this.tasaInteres = tasaInteres;
    }

    @Override
    public boolean retirar(double monto) {
        if (monto <= 0 || monto > saldo) return false;
        saldo -= monto;
        return true;
    }

    public double calcularInteres() { return saldo * tasaInteres; }
    @Override public String getTipo() { return "Ahorros"; }
}
