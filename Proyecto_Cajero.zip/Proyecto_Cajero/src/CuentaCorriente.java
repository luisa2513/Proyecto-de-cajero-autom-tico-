// Cuenta corriente: hereda de Cuenta. Permite retirar más que el saldo hasta el sobregiro.
public class CuentaCorriente extends Cuenta {
    private final double sobregiroPermitido;

    public CuentaCorriente(String numero, double saldoInicial, double sobregiroPermitido) {
        super(numero, saldoInicial);
        this.sobregiroPermitido = sobregiroPermitido;
    }

    @Override
    public boolean retirar(double monto) {
        if (monto <= 0 || monto > saldo + sobregiroPermitido) return false;
        saldo -= monto;
        return true;
    }

    @Override public String getTipo() { return "Corriente"; }
}
