// Guarda los datos de cada operación (tipo, monto, fecha y si fue exitosa) para el historial.
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Transaccion {
    private static int contador = 0;

    private final String idTransaccion;
    private final String tipo;
    private final double monto;
    private final LocalDateTime fecha;
    private final boolean exitosa;
    private final String cuenta;

    public Transaccion(String tipo, String cuenta, double monto, boolean exitosa) {
        this.idTransaccion = String.format("TX-%05d", ++contador);
        this.tipo = tipo;
        this.cuenta = cuenta;
        this.monto = monto;
        this.exitosa = exitosa;
        this.fecha = LocalDateTime.now();
    }

    public String getComprobante() {
        return String.format("%s | %s | Cuenta %s | $%,.0f | %s | %s",
                idTransaccion, tipo, cuenta, monto,
                fecha.format(DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss")),
                exitosa ? "EXITOSA" : "RECHAZADA");
    }

    public String getTipo() { return tipo; }
    public boolean isExitosa() { return exitosa; }
    public double getMonto() { return monto; }
}
