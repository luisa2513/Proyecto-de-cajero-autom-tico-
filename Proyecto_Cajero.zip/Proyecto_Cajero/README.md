# Cajero Automático (Java)

Requiere JDK 17 o superior.

    cd src
    javac -encoding UTF-8 *.java
    java Main

Tarjeta de prueba: `4000123412341234` — PIN: `1234`
(Tres PIN incorrectos seguidos bloquean la tarjeta.)

Reglas: retiro máximo $1.000.000, en múltiplos de $10.000; la cuenta corriente permite sobregiro de $100.000.
